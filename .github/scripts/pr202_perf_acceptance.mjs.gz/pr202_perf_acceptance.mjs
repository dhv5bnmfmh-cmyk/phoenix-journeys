import { pathToFileURL } from 'node:url';
const { chromium, webkit, devices } = await import(pathToFileURL(process.env.PLAYWRIGHT_PATH).href);

const baseUrl = process.env.PERF_URL;
const sourceSha = process.env.CANDIDATE_SHA;
const browserName = process.env.PROBE_BROWSER;
const cityKey = process.env.PROBE_CITY;
if (!baseUrl || !sourceSha || !browserName || !cityKey) throw new Error('missing PERF_URL/CANDIDATE_SHA/PROBE_BROWSER/PROBE_CITY');

const cityMap = {
  beijing: { city: '北京', place: '紫禁城', title: '北京 · 紫禁城', actor: '沈砚' },
  shanghai: { city: '上海', place: '外滩', title: '上海 · 外滩', actor: '林岸' },
  xian: { city: '西安', place: '城墙', title: '西安 · 城墙', actor: '周遥' },
};
const journey = cityMap[cityKey];
if (!journey) throw new Error(`unsupported city ${cityKey}`);

const thresholds = { badge: 300, content: 800, interactive: 1200 };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const clean = (v) => String(v ?? '').replace(/\s+/g, ' ').trim();

async function records(page) {
  return page.locator('flt-semantics').evaluateAll((elements) => elements.map((element, index) => {
    const rect = element.getBoundingClientRect();
    const style = getComputedStyle(element);
    return {
      index,
      role: element.getAttribute('role'),
      label: element.getAttribute('aria-label') || '',
      value: element.getAttribute('aria-valuetext') || '',
      description: element.getAttribute('aria-description') || '',
      text: String(element.textContent || '').replace(/\s+/g, ' ').trim(),
      disabled: element.getAttribute('aria-disabled') === 'true',
      visible: rect.width > 0 && rect.height > 0 && style.display !== 'none' && style.visibility !== 'hidden',
      area: rect.width * rect.height,
    };
  }));
}
const recordText = (r) => clean([r.label, r.value, r.description, r.text].filter(Boolean).join(' '));
async function visibleText(page) {
  return (await records(page)).filter((r) => r.visible).map(recordText).filter(Boolean).join('\n');
}
async function findSemantic(page, needle, { role = null, prefix = false, timeout = 20000 } = {}) {
  const wanted = clean(needle); const deadline = Date.now() + timeout;
  while (Date.now() < deadline) {
    const matches = (await records(page)).filter((r) => {
      if (!r.visible || (role && r.role !== role)) return false;
      const text = recordText(r); return prefix ? text.startsWith(wanted) : text.includes(wanted);
    }).sort((a,b) => {
      if (a.role === 'button' && b.role !== 'button') return -1;
      if (b.role === 'button' && a.role !== 'button') return 1;
      return a.area - b.area;
    });
    if (matches.length) return page.locator('flt-semantics').nth(matches[0].index);
    await sleep(60);
  }
  throw new Error(`semantic state not found: ${needle}`);
}
async function exists(page, needle, options = {}) {
  try { await findSemantic(page, needle, { ...options, timeout: options.timeout ?? 600 }); return true; }
  catch (_) { return false; }
}
async function activate(page, needle, { prefix = false, timeout = 20000 } = {}) {
  const deadline = Date.now() + timeout;
  let lastError = null;
  while (Date.now() < deadline) {
    try {
      const node = await findSemantic(page, needle, { role: 'button', prefix, timeout: Math.min(1600, deadline - Date.now()) });
      const disabled = await node.getAttribute('aria-disabled').catch(() => null);
      if (disabled === 'true') throw new Error(`button disabled: ${needle}`);
      await node.evaluate((element) => element.click());
      return;
    } catch (e) { lastError = e; if (String(e?.message || e).includes('button disabled:')) throw e; await sleep(70); }
  }
  throw lastError ?? new Error(`button not activatable: ${needle}`);
}
async function clickSemantic(page, needle, { prefix = false, timeout = 20000 } = {}) {
  const node = await findSemantic(page, needle, { prefix, timeout });
  await node.evaluate((element) => element.click());
}
async function enableSemantics(page) {
  const deadline = Date.now() + 60000;
  while (Date.now() < deadline) {
    const placeholder = page.locator('flt-semantics-placeholder').first();
    if (await placeholder.count()) await placeholder.evaluate((e) => e.click());
    if (await page.locator('flt-semantics').count()) return;
    await sleep(80);
  }
  throw new Error('Flutter semantics did not become available');
}
async function startup(page) {
  const sep = baseUrl.includes('?') ? '&' : '?';
  const url = `${baseUrl}${sep}unlock=all&prototype=journeys&v=${sourceSha}`;
  const response = await page.goto(url, { waitUntil: 'load', timeout: 140000 });
  if (!response?.ok()) throw new Error(`Preview HTTP load failed: ${response?.status()}`);
  await page.waitForFunction(() => document.querySelector('flutter-view') != null, null, { timeout: 140000 });
  await page.waitForFunction(() => document.getElementById('phoenix-loading') == null, null, { timeout: 45000 });
  await enableSemantics(page);
  await findSemantic(page, 'PHOENIX JOURNEYS', { timeout: 30000 });
}
async function waitStage(page, n, timeout = 20000) { await findSemantic(page, `${n}/6`, { prefix: true, timeout }); }
async function currentLevel(page) {
  const labels = await page.locator('flt-semantics').evaluateAll((els) => els.map((e) => e.getAttribute('aria-label') || '').filter((x) => x.includes('Phoenix 中文难度')));
  for (const label of labels) { const m = label.match(/Phoenix 中文难度\s*(\d+)\s*级/); if (m) return Number(m[1]); }
  const text = await visibleText(page); const m = text.match(/Phoenix 中文难度\s*(\d+)\s*级/); if (m) return Number(m[1]);
  throw new Error('Phoenix level selector not found');
}
async function levelButton(page, delta) {
  return findSemantic(page, delta > 0 ? '提高当前难度' : '降低当前难度', { role: 'button', prefix: true, timeout: 5000 });
}
async function rawLevelClick(page, delta) {
  const node = await levelButton(page, delta); await node.evaluate((e) => e.click());
}
async function setLevel(page, target) {
  for (let i=0;i<20;i++) {
    const cur = await currentLevel(page); if (cur === target) return;
    await rawLevelClick(page, cur < target ? 1 : -1);
    const deadline = Date.now() + 4000;
    while (Date.now() < deadline) { if ((await currentLevel(page).catch(() => cur)) !== cur) break; await sleep(30); }
  }
  throw new Error(`failed setLevel ${target}; got ${await currentLevel(page)}`);
}
async function openJourney(page) {
  await activate(page, '选择城市', { prefix: true });
  await findSemantic(page, '选择城市与地点', { timeout: 15000 });
  await activate(page, journey.city, { prefix: true });
  await findSemantic(page, `${journey.city}的地点`, { timeout: 15000 });
  await activate(page, journey.place, { prefix: true });
  await sleep(250);
  if (await exists(page, 'PHOENIX JOURNEYS', { timeout: 1500 })) {
    let started = false;
    for (const action of ['开始', '继续', '再次探索']) {
      if (await exists(page, action, { role:'button', prefix:true, timeout:700 })) { await activate(page, action, { prefix:true }); started = true; break; }
    }
    if (!started) throw new Error('journey start action missing');
  }
  await waitStage(page, 1, 20000);
  await findSemantic(page, journey.title, { timeout: 15000 });
  await findSemantic(page, journey.actor, { timeout: 15000 });
}
async function dismissModal(page) {
  await page.mouse.click(8, 8); await sleep(180);
}
async function ensureVocabularyPopupClosed(page) {
  if (await exists(page, '已下载例句', { timeout: 300 })) await dismissModal(page);
}

async function challengeOptionTargets(page) {
  const rs = await records(page);
  const toTarget = (r) => ({ role:r.role, label:clean(r.label), text:recordText(r) });
  const lettered = rs.filter((r) => r.visible && !r.disabled && /^[A-D]\s/.test(clean(r.label)) && /[\u3400-\u9fff]/.test(clean(r.label))).sort((a,b)=>a.index-b.index);
  if (lettered.length) return lettered.map(toTarget);
  const excluded = ['提交第','朗读','进入下一种挑战','完成三连挑战','再练重点项','继续留下回忆','完成挑战后继续','返回','Back','查看 Lv.','提高当前难度','降低当前难度','短文复原','语病修复','补回句子','简 / 繁','声线','减速','加速','提示'];
  return rs.filter((r) => {
    if (!r.visible || r.disabled || !['button','group','checkbox'].includes(r.role)) return false;
    const text = recordText(r); if (text.length < 2 || !/[\u3400-\u9fff]/.test(text)) return false;
    return !excluded.some((x)=>text.includes(x));
  }).sort((a,b)=>b.area-a.area).map(toTarget);
}
async function requiredChallengeSelections(page) {
  const text = await visibleText(page); const m = text.match(/依次点击\s*(\d+)\s*句/); return m ? Number(m[1]) : 1;
}
async function chooseChallenge(page) {
  const text = await visibleText(page);
  if (text.includes('第一步 · 点击有问题的部分')) {
    const rs=await records(page); const segments=rs.filter((r)=>r.visible&&!r.disabled&&r.role==='checkbox'&&/[\u3400-\u9fff]/.test(recordText(r))).sort((a,b)=>a.index-b.index);
    if (segments.length) await page.locator('flt-semantics').nth(segments[0].index).evaluate((e)=>e.click());
    await sleep(80);
  }
  const count = await requiredChallengeSelections(page); const targets = await challengeOptionTargets(page);
  if (targets.length < count) throw new Error(`only ${targets.length} challenge targets; need ${count}`);
  for (const t of targets.slice(0,count)) {
    const rs=await records(page); const matches=rs.filter((r)=>r.visible&&!r.disabled&&((t.label&&clean(r.label)===t.label)||(!t.label&&r.role===t.role&&recordText(r)===t.text))).sort((a,b)=>a.area-b.area);
    if (!matches.length) throw new Error('challenge target disappeared');
    await page.locator('flt-semantics').nth(matches[0].index).evaluate((e)=>e.click()); await sleep(70);
  }
}
async function completeChallenge(page) {
  for (let mode=0; mode<3; mode++) {
    let resolved=false;
    for (let attempt=1; attempt<=3; attempt++) {
      await chooseChallenge(page);
      await activate(page,'提交第',{prefix:true});
      await sleep(350);
      if (await exists(page,'进入下一种挑战',{role:'button',timeout:1000})) { await activate(page,'进入下一种挑战'); resolved=true; break; }
      if (await exists(page,'完成三连挑战',{role:'button',timeout:1000})) { await activate(page,'完成三连挑战'); resolved=true; break; }
      if (attempt<3) await findSemantic(page,`提交第 ${attempt+1} / 3 次答案`,{role:'button',prefix:true,timeout:4000});
    }
    if (!resolved && mode<2) throw new Error(`challenge mode ${mode+1} not resolved`);
  }
  await findSemantic(page,'继续留下回忆',{role:'button',prefix:true,timeout:12000});
}
async function completeJourneyOnce(page) {
  await setLevel(page,5);
  await activate(page,'继续',{prefix:true});
  await findSemantic(page,'已下载例句',{timeout:12000});
  await dismissModal(page); await waitStage(page,2);
  await activate(page,'继续',{prefix:true}); await waitStage(page,3);
  await activate(page,'继续',{prefix:true}); await waitStage(page,4);
  await completeChallenge(page);
  await activate(page,'继续留下回忆',{prefix:true}); await waitStage(page,5);
  if (await exists(page,'保存回忆并完成',{role:'button',prefix:true,timeout:800})) await activate(page,'保存回忆并完成',{prefix:true});
  else await activate(page,'结束旅程',{prefix:true});
  await waitStage(page,6); await findSemantic(page,'已点亮',{timeout:15000});
}
const stageNames = ['Story','Vocabulary','Discovery','Challenge','Memory','Completion'];
const stageLabels = ['故事','单词','发现','挑战','回忆','完成'];
async function selectStage(page, stage) {
  const target=stage+1;
  if ((await visibleText(page)).includes(`${target}/6`)) { await ensureVocabularyPopupClosed(page); return; }
  await clickSemantic(page,'课程已完成 · 可自由选择',{timeout:5000});
  await findSemantic(page,'选择 Journey 阶段',{timeout:5000}).catch(()=>{});
  await activate(page,stageLabels[stage],{prefix:false,timeout:8000});
  await waitStage(page,target,12000); await ensureVocabularyPopupClosed(page); await sleep(120);
}

const commonDrop = [
  'Phoenix 中文难度','提高当前难度','降低当前难度','查看 Lv.','已即时应用到当前故事与挑战','简 / 繁',
  '课程已完成 · 可自由选择','请按顺序完成课程','下一步','上一步','返回首页','重新体验','分享旅程',
  '开始朗读','暂停朗读','继续朗读','重新播放','声线与朗读速度控制','减速','加速','速度','进度',
  '1/6','2/6','3/6','4/6','5/6','6/6','故事 单词 发现 挑战 回忆 完成'
];
function fnv(text){ let h=0x811c9dc5; for(const c of new TextEncoder().encode(text)){h^=c;h=Math.imul(h,0x01000193)>>>0;} return h.toString(16).padStart(8,'0'); }
async function learnerState(page, stage) {
  const rs=await records(page); const lines=[];
  for(const r of rs){
    if(!r.visible) continue; const t=recordText(r); if(!t||t.length<2) continue;
    if(commonDrop.some((x)=>t.includes(x))) continue;
    if(/^\d+\s*\/\s*6/.test(t)) continue;
    if(stage!==3 && t.includes('提交第')) continue;
    lines.push(t);
  }
  const unique=[...new Set(lines)].sort(); const text=unique.join('\n');
  return { hash:fnv(text), text, count:unique.length };
}
async function interactionReady(page, stage) {
  try {
    if(stage===0) return await exists(page,'注',{role:'button',timeout:120}) && await exists(page,'继续',{role:'button',prefix:true,timeout:120});
    if(stage===1) {
      const rs=await records(page); const words=rs.filter((r)=>r.visible&&!r.disabled&&r.role==='button'&&/[\u3400-\u9fff]/.test(recordText(r))&&!['继续','上一步','提高当前难度','降低当前难度'].some((x)=>recordText(r).includes(x)));
      return words.length>0 && await exists(page,'继续',{role:'button',prefix:true,timeout:120});
    }
    if(stage===2) return await exists(page,'注',{role:'button',timeout:120}) && await exists(page,'继续',{role:'button',prefix:true,timeout:120});
    if(stage===3) return (await challengeOptionTargets(page)).length>0;
    if(stage===4) return (await exists(page,'播放朗读',{role:'button',timeout:120})) && ((await exists(page,'保存回忆并完成',{role:'button',prefix:true,timeout:120})) || (await exists(page,'结束旅程',{role:'button',prefix:true,timeout:120})));
    return (await exists(page,'播放朗读',{role:'button',timeout:120})) && (await exists(page,'返回首页',{role:'button',prefix:true,timeout:120}));
  } catch(_) { return false; }
}
async function measureSwitch(page, stage, target, tag) {
  const from=await currentLevel(page); if(from===target) throw new Error(`measure ${tag} already target`);
  const source=await learnerState(page,stage);
  const requests=[]; const handler=(req)=>requests.push(req.url()); page.on('request',handler);
  const t0=performance.now();
  await rawLevelClick(page,target>from?1:-1);
  let t1=null,t2=null,t3=null,t4=null, targetState=null, stableHash=null, stableSince=null;
  const deadline=t0+5000;
  while(performance.now()<deadline){
    const now=performance.now();
    const level=await currentLevel(page).catch(()=>from);
    if(t1==null&&level===target) t1=now;
    if(level===target){
      const state=await learnerState(page,stage); targetState=state;
      if(t2==null && (state.hash!==source.hash || (t1!=null && now-t1>=70))) t2=now;
      if(t2!=null){ if(stableHash===state.hash){ if(stableSince==null) stableSince=now; if(t3==null&&now-stableSince>=90)t3=now; } else {stableHash=state.hash;stableSince=now;} }
      if(t4==null && await interactionReady(page,stage)) t4=now;
    }
    if(t1&&t2&&t3&&t4) break;
    await sleep(22);
  }
  page.off('request',handler);
  if(!t1||!t2||!t3||!t4) throw new Error(`${tag} timing incomplete t1=${t1} t2=${t2} t3=${t3} t4=${t4}`);
  const out={tag,stage:stage+1,from,to:target,badgeMs:Math.round(t1-t0),contentMs:Math.round(t2-t0),semanticStableMs:Math.round(t3-t0),interactiveMs:Math.round(t4-t0),contentChanged:targetState.hash!==source.hash,sourceHash:source.hash,targetHash:targetState.hash,requestCount:requests.length,requestUrls:[...new Set(requests)].slice(0,12)};
  out.pass=out.badgeMs<=thresholds.badge&&out.contentMs<=thresholds.content&&out.interactiveMs<=thresholds.interactive;
  console.log(`PERF_SAMPLE ${cityKey} ${browserName} ${stageNames[stage]} ${JSON.stringify(out)}`);
  return out;
}
async function measureStage(page, stage) {
  await selectStage(page,stage); await setLevel(page,5); await sleep(220);
  const results=[];
  results.push(await measureSwitch(page,stage,6,'5>6-cold'));
  results.push(await measureSwitch(page,stage,5,'6>5-reverse'));
  results.push(await measureSwitch(page,stage,6,'5>6-warm2'));
  await setLevel(page,5); results.push(await measureSwitch(page,stage,6,'5>6-warm3'));
  await setLevel(page,8); await sleep(160);
  results.push(await measureSwitch(page,stage,9,'8>9-cold'));
  results.push(await measureSwitch(page,stage,8,'9>8-reverse'));
  results.push(await measureSwitch(page,stage,9,'8>9-warm2'));
  await setLevel(page,8); results.push(await measureSwitch(page,stage,9,'8>9-warm3'));
  const metric=(name,arr=results)=>{const vals=arr.map((x)=>x[name]).sort((a,b)=>a-b); const mid=vals.length/2; return {median:vals.length%2?vals[Math.floor(mid)]:(vals[mid-1]+vals[mid])/2,worst:Math.max(...vals)};};
  const cold=results.filter((r)=>r.tag.endsWith('cold')); const warm=results.filter((r)=>r.tag.includes('warm'));
  const summary={stage:stage+1,name:stageNames[stage],pass:results.every((r)=>r.pass),badge:{...metric('badgeMs'),cold:metric('badgeMs',cold),warm:metric('badgeMs',warm)},content:{...metric('contentMs'),cold:metric('contentMs',cold),warm:metric('contentMs',warm)},interactive:{...metric('interactiveMs'),cold:metric('interactiveMs',cold),warm:metric('interactiveMs',warm)},results};
  console.log(`PERF_STAGE ${cityKey} ${browserName} ${JSON.stringify(summary)}`); return summary;
}
async function proveStageInteraction(page,stage){
  await selectStage(page,stage); await setLevel(page,6); await sleep(150);
  if(stage===0||stage===2){ await activate(page,'注'); await sleep(180); const t=await visibleText(page); if(!t.includes('Pinyin')&&!t.includes('English')) throw new Error(`${stageNames[stage]} Reading Support did not open`); await dismissModal(page); return; }
  if(stage===1){
    const rs=await records(page); const candidates=rs.filter((r)=>r.visible&&!r.disabled&&r.role==='button'&&/[\u3400-\u9fff]/.test(recordText(r))&&!['继续','上一步','提高当前难度','降低当前难度','查看 Lv.'].some((x)=>recordText(r).includes(x))).sort((a,b)=>b.area-a.area);
    if(!candidates.length) throw new Error('Vocabulary word card not interactive'); await page.locator('flt-semantics').nth(candidates[0].index).evaluate((e)=>e.click()); await findSemantic(page,'已下载例句',{timeout:7000}); await dismissModal(page); return;
  }
  if(stage===3){ const targets=await challengeOptionTargets(page); if(!targets.length) throw new Error('Challenge no interaction target'); const r=await records(page); const x=r.find((q)=>q.visible&&!q.disabled&&((targets[0].label&&clean(q.label)===targets[0].label)||(!targets[0].label&&q.role===targets[0].role&&recordText(q)===targets[0].text))); await page.locator('flt-semantics').nth(x.index).evaluate((e)=>e.click()); return; }
  if(stage===4||stage===5){ await activate(page,'播放朗读'); await findSemantic(page,'停止朗读',{role:'button',timeout:5000}); await activate(page,'停止朗读'); return; }
}
async function runRapidAndRaceScenarios(page) {
  const out={};
  await selectStage(page,0); await setLevel(page,5);
  // idle 5 -> 6 -> 7
  await rawLevelClick(page,1); await rawLevelClick(page,1); await sleep(450); out.idleUp={level:await currentLevel(page),speed:(await visibleText(page)).match(/当前速度\s*([^\s]+)/)?.[1]||null}; if(out.idleUp.level!==7) throw new Error('rapid idle 5>6>7 latest intent failed');
  // reverse 7 -> 6 -> 5
  await rawLevelClick(page,-1); await rawLevelClick(page,-1); await sleep(450); out.idleDown={level:await currentLevel(page)}; if(out.idleDown.level!==5) throw new Error('rapid 7>6>5 latest intent failed');
  // mixed + + - + = 7
  await rawLevelClick(page,1); await rawLevelClick(page,1); await rawLevelClick(page,-1); await rawLevelClick(page,1); await sleep(500); out.mixed={level:await currentLevel(page)}; if(out.mixed.level!==7) throw new Error('mixed rapid latest intent failed');
  // Story narration playing; cut over then immediately restart latest narration.
  await setLevel(page,5); await activate(page,'开始朗读'); await findSemantic(page,'正在朗读',{timeout:6000}); await rawLevelClick(page,1);
  const d1=Date.now()+2500; while(Date.now()<d1 && await currentLevel(page)!==6) await sleep(20);
  await activate(page,'开始朗读',{timeout:5000}); await sleep(700); if(!(await exists(page,'正在朗读',{timeout:700}))) throw new Error('stale Story cleanup stopped latest narration'); out.storyNarration={level:await currentLevel(page),playing:true}; await activate(page,'暂停朗读').catch(()=>{});
  // Discovery narration playing.
  await selectStage(page,2); await setLevel(page,5); if(await exists(page,'正在朗读',{timeout:300})) await activate(page,'暂停朗读').catch(()=>{}); if(await exists(page,'开始朗读',{timeout:1000})) await activate(page,'开始朗读'); else if(await exists(page,'继续朗读',{timeout:1000})) await activate(page,'继续朗读'); await findSemantic(page,'正在朗读',{timeout:6000}); await rawLevelClick(page,1); const d2=Date.now()+2500; while(Date.now()<d2 && await currentLevel(page)!==6) await sleep(20); if(await exists(page,'开始朗读',{timeout:1200})) await activate(page,'开始朗读'); else if(await exists(page,'继续朗读',{timeout:1200})) await activate(page,'继续朗读'); await sleep(700); if(!(await exists(page,'正在朗读',{timeout:700}))) throw new Error('stale Discovery cleanup stopped latest narration'); out.discoveryNarration={level:await currentLevel(page),playing:true}; await activate(page,'暂停朗读').catch(()=>{});
  // Vocabulary popup open during underlying level change.
  await selectStage(page,1); await setLevel(page,5); const rs=await records(page); const words=rs.filter((r)=>r.visible&&!r.disabled&&r.role==='button'&&/[\u3400-\u9fff]/.test(recordText(r))&&!['继续','上一步','提高当前难度','降低当前难度'].some((x)=>recordText(r).includes(x))).sort((a,b)=>b.area-a.area); if(!words.length) throw new Error('Vocabulary popup setup missing word'); await page.locator('flt-semantics').nth(words[0].index).evaluate((e)=>e.click()); await findSemantic(page,'已下载例句',{timeout:6000}); await rawLevelClick(page,1); await sleep(450); out.vocabPopup={level:await currentLevel(page),popupStillOpen:await exists(page,'已下载例句',{timeout:250})};
  if(out.vocabPopup.popupStillOpen) throw new Error('old Vocabulary popup survived level change');
  // Challenge untouched then partial selection must reset on level switch.
  await selectStage(page,3); await setLevel(page,5); const untouched=await challengeOptionTargets(page); if(!untouched.length) throw new Error('Challenge untouched missing controls'); await proveStageInteraction(page,3); await rawLevelClick(page,1); await sleep(400); const text=await visibleText(page); out.challengePartial={level:await currentLevel(page),firstAttempt:text.includes('提交第 1 / 3 次答案')}; if(!out.challengePartial.firstAttempt) throw new Error('old Challenge partial state survived level change');
  // Memory/Completion active level consistency and narration.
  for(const s of [4,5]){ await selectStage(page,s); await setLevel(page,5); await rawLevelClick(page,1); await sleep(350); if(await currentLevel(page)!==6) throw new Error(`${stageNames[s]} level drift`); await proveStageInteraction(page,s); }
  // Persistence: final level 7 must survive reload.
  await selectStage(page,0); await setLevel(page,5); await rawLevelClick(page,1); await rawLevelClick(page,1); await sleep(900); if(await currentLevel(page)!==7) throw new Error('final visible level before reload !=7');
  await page.reload({waitUntil:'load',timeout:140000}); await page.waitForFunction(()=>document.querySelector('flutter-view')!=null,null,{timeout:140000}); await page.waitForFunction(()=>document.getElementById('phoenix-loading')==null,null,{timeout:45000}); await enableSemantics(page); await findSemantic(page,'PHOENIX JOURNEYS',{timeout:30000});
  // Resume active Journey if home.
  if(!(await exists(page,'1/6',{prefix:true,timeout:1000}))){ for(const action of ['继续','再次探索','开始']){ if(await exists(page,action,{role:'button',prefix:true,timeout:600})){ await activate(page,action,{prefix:true}); break; } } }
  await waitStage(page,1,15000); out.persisted={level:await currentLevel(page)}; if(out.persisted.level!==7) throw new Error(`saved Phoenix level latest intent failed after reload: ${out.persisted.level}`);
  return out;
}

const browserType=browserName==='webkit'?webkit:chromium;
const browser=await browserType.launch({headless:true});
const context=browserName==='webkit' ? await browser.newContext({...devices['iPhone 13']}) : await browser.newContext({viewport:{width:1440,height:1000}});
const page=await context.newPage();
const pageErrors=[]; const failedRequests=[];
page.on('pageerror',(e)=>pageErrors.push(String(e)));
page.on('requestfailed',(r)=>failedRequests.push(`${r.method()} ${r.url()} ${r.failure()?.errorText||''}`));
const output={sha:sourceSha,cityKey,city:journey.city,place:journey.place,browser:browserName,thresholds,stages:{},special:{},pageErrors,failedRequests,pass:false};
try{
  await startup(page); await openJourney(page); await completeJourneyOnce(page);
  for(let stage=0;stage<6;stage++){ output.stages[stage+1]=await measureStage(page,stage); await proveStageInteraction(page,stage); }
  output.special=await runRapidAndRaceScenarios(page);
  output.pass=Object.values(output.stages).every((s)=>s.pass)&&pageErrors.length===0;
}catch(error){output.error=String(error?.stack||error);}
finally{console.log(`PERF_RESULT_JSON=${JSON.stringify(output)}`);await browser.close();}
if(!output.pass) process.exitCode=1;
