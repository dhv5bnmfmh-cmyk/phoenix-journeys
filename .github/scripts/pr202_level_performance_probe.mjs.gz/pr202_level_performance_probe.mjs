import { pathToFileURL } from 'node:url';

const { chromium, webkit, devices } = await import(
  pathToFileURL(process.env.PLAYWRIGHT_PATH).href
);

const previewUrl = process.env.PREVIEW_URL;
const sourceSha = process.env.CANDIDATE_SHA;
const browserName = process.env.PROBE_BROWSER;
const cityKey = process.env.PROBE_CITY;

if (!previewUrl || !sourceSha || !browserName || !cityKey) {
  throw new Error('missing PREVIEW_URL/CANDIDATE_SHA/PROBE_BROWSER/PROBE_CITY');
}

const journeys = {
  beijing: { city: '北京', place: '紫禁城', title: '北京 · 紫禁城' },
  shanghai: { city: '上海', place: '外滩', title: '上海 · 外滩' },
  xian: { city: '西安', place: '西安城墙', title: '西安 · 城墙' },
};
const journey = journeys[cityKey];
if (!journey) throw new Error(`unknown city key: ${cityKey}`);

const thresholds = { badge: 300, content: 800, interactive: 1200 };
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const now = () => performance.now();
const clean = (value) => String(value ?? '').replace(/\s+/g, ' ').trim();

async function records(page) {
  return page.locator('flt-semantics').evaluateAll((elements) =>
    elements.map((element, index) => {
      const rect = element.getBoundingClientRect();
      const style = getComputedStyle(element);
      return {
        index,
        role: element.getAttribute('role'),
        label: element.getAttribute('aria-label') || '',
        value: element.getAttribute('aria-valuetext') || '',
        description: element.getAttribute('aria-description') || '',
        text: String(element.textContent || '').replace(/\s+/g, ' ').trim(),
        disabled: element.getAttribute('aria-disabled') === 'true',
        visible:
          rect.width > 0 &&
          rect.height > 0 &&
          style.display !== 'none' &&
          style.visibility !== 'hidden',
        area: rect.width * rect.height,
      };
    }),
  );
}

const recordText = (record) =>
  clean([record.label, record.value, record.description, record.text].filter(Boolean).join(' '));

async function visibleText(page) {
  return (await records(page))
    .filter((record) => record.visible)
    .map(recordText)
    .filter(Boolean)
    .join('\n');
}

async function findSemantic(page, needle, { role = null, prefix = false, timeout = 10000 } = {}) {
  const deadline = Date.now() + timeout;
  const wanted = clean(needle);
  while (Date.now() < deadline) {
    const matches = (await records(page))
      .filter((record) => {
        if (!record.visible || (role && record.role !== role)) return false;
        const text = recordText(record);
        return prefix ? text.startsWith(wanted) : text.includes(wanted);
      })
      .sort((left, right) => {
        if (left.role === 'button' && right.role !== 'button') return -1;
        if (right.role === 'button' && left.role !== 'button') return 1;
        return left.area - right.area;
      });
    if (matches.length) return page.locator('flt-semantics').nth(matches[0].index);
    await sleep(25);
  }
  throw new Error(`semantic state not found: ${needle}`);
}

async function exists(page, needle, options = {}) {
  try {
    await findSemantic(page, needle, { ...options, timeout: options.timeout ?? 300 });
    return true;
  } catch (_) {
    return false;
  }
}

async function tapButton(page, needle, { prefix = false, exact = false, timeout = 10000 } = {}) {
  const deadline = Date.now() + timeout;
  const wanted = clean(needle);
  let lastError = null;
  while (Date.now() < deadline) {
    try {
      const rs = await records(page);
      const matches = rs
        .filter((record) => {
          if (!record.visible || record.role !== 'button' || record.disabled) return false;
          const text = recordText(record);
          if (exact) return text === wanted;
          return prefix ? text.startsWith(wanted) : text.includes(wanted);
        })
        .sort((a, b) => a.area - b.area);
      if (!matches.length) throw new Error(`button missing: ${needle}`);
      await page.locator('flt-semantics').nth(matches[0].index).evaluate((el) => el.click());
      return;
    } catch (error) {
      lastError = error;
      await sleep(25);
    }
  }
  throw lastError ?? new Error(`button not activatable: ${needle}`);
}

async function enableSemantics(page) {
  const deadline = Date.now() + 60000;
  while (Date.now() < deadline) {
    const placeholder = page.locator('flt-semantics-placeholder').first();
    if (await placeholder.count()) await placeholder.evaluate((el) => el.click());
    if (await page.locator('flt-semantics').count()) return;
    await sleep(50);
  }
  throw new Error('Flutter semantics did not become available');
}

async function startup(page) {
  const sep = previewUrl.includes('?') ? '&' : '?';
  const url = `${previewUrl}${sep}unlock=all&prototype=journeys&v=${sourceSha}`;
  const response = await page.goto(url, { waitUntil: 'load', timeout: 140000 });
  if (!response?.ok()) throw new Error(`Preview HTTP load failed: ${response?.status()}`);
  await page.waitForFunction(() => document.querySelector('flutter-view') != null, null, { timeout: 140000 });
  await page.waitForFunction(() => document.getElementById('phoenix-loading') == null, null, { timeout: 45000 });
  await enableSemantics(page);
  await findSemantic(page, 'PHOENIX JOURNEYS', { timeout: 30000 });
}

async function currentLevel(page) {
  for (const record of await records(page)) {
    if (!record.visible) continue;
    const match = recordText(record).match(/Phoenix 中文难度\s*(\d+)\s*级/);
    if (match) return Number(match[1]);
  }
  throw new Error('Phoenix level selector not found');
}

async function currentStage(page) {
  const rs = await records(page);
  const stages = [];
  for (const record of rs) {
    if (!record.visible) continue;
    const match = recordText(record).match(/^([1-6])\/6(?:\s|$)/);
    if (match) stages.push(Number(match[1]));
  }
  if (stages.length) return Math.max(...stages);
  const text = await visibleText(page);
  const fallback = text.match(/(?:^|\n)([1-6])\/6(?:\s|\n|$)/);
  return fallback ? Number(fallback[1]) : null;
}

async function waitStage(page, stage, timeout = 15000) {
  const deadline = Date.now() + timeout;
  while (Date.now() < deadline) {
    if ((await currentStage(page).catch(() => null)) === stage) return;
    await sleep(50);
  }
  throw new Error(`stage ${stage}/6 not reached`);
}

async function openJourney(page) {
  if ((await currentStage(page).catch(() => null)) === 1 && (await visibleText(page)).includes(journey.title)) return;
  await tapButton(page, '选择城市', { prefix: true });
  await findSemantic(page, '选择城市与地点', { timeout: 15000 });
  await tapButton(page, journey.city, { exact: true, timeout: 15000 });
  await findSemantic(page, `${journey.city}的地点`, { timeout: 15000 });
  await tapButton(page, journey.place, { exact: true, timeout: 15000 });

  const deadline = Date.now() + 15000;
  while (Date.now() < deadline) {
    if ((await currentStage(page).catch(() => null)) === 1) return;
    if (await exists(page, 'PHOENIX JOURNEYS', { timeout: 150 })) break;
    await sleep(100);
  }

  const rs = await records(page);
  const actions = rs
    .filter((record) =>
      record.visible &&
      record.role === 'button' &&
      !record.disabled &&
      /^(开始|继续|再次探索)/.test(recordText(record)),
    )
    .sort((a, b) => b.area - a.area);
  if (!actions.length) throw new Error(`Journey launch action missing for ${journey.city}/${journey.place}`);
  await page.locator('flt-semantics').nth(actions[0].index).evaluate((el) => el.click());
  await waitStage(page, 1, 20000);
}

function globalNoise(text) {
  if (!text) return true;
  return (
    /Phoenix 中文难度/.test(text) ||
    /^查看 Lv\./.test(text) ||
    /^(提高当前难度|降低当前难度)/.test(text) ||
    /^\d\/6(?:\s|$)/.test(text) ||
    /已即时应用到当前故事与挑战/.test(text) ||
    /^(Back|返回|上一步|继续|下一步|重新播放|简 \/ 繁|选择朗读声线|声线选择|自动减速|减速|加速)$/.test(text) ||
    /^(故事|单词|发现|挑战|旅程回忆|完成)$/.test(text)
  );
}

async function canonicalStageText(page, stage) {
  const rs = await records(page);
  const lines = [];
  for (const record of rs) {
    if (!record.visible) continue;
    const text = recordText(record);
    if (globalNoise(text)) continue;
    if (stage !== 6 && /^(返回首页|分享旅程|重新体验)$/.test(text)) continue;
    if (/^Lv\.\d+$/.test(text)) continue;
    lines.push(`${record.role || ''}|${text}`);
  }
  return lines.join('\n');
}

function hashText(value) {
  let h = 2166136261;
  for (let i = 0; i < value.length; i += 1) {
    h ^= value.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16).padStart(8, '0');
}

async function waitCanonicalStable(page, stage, { differentFrom = null, timeout = 5000, stableMs = 220 } = {}) {
  const deadline = now() + timeout;
  let stableSince = null;
  let lastHash = null;
  let lastText = '';
  let firstChangedAt = null;
  while (now() < deadline) {
    const text = await canonicalStageText(page, stage);
    const hash = hashText(text);
    const changed = differentFrom == null || hash !== differentFrom;
    if (changed && firstChangedAt == null) firstChangedAt = now();
    if (changed && hash === lastHash) {
      if (stableSince == null) stableSince = now();
      if (now() - stableSince >= stableMs) {
        return { text, hash, firstChangedAt };
      }
    } else {
      stableSince = changed ? now() : null;
    }
    lastHash = hash;
    lastText = text;
    await sleep(25);
  }
  return { text: lastText, hash: hashText(lastText), firstChangedAt, timeout: true };
}

async function waitButtonEnabled(page, predicate, timeout = 2500) {
  const deadline = now() + timeout;
  while (now() < deadline) {
    const rs = await records(page);
    const match = rs.find((r) => r.visible && r.role === 'button' && !r.disabled && predicate(recordText(r), r));
    if (match) return match;
    await sleep(25);
  }
  return null;
}

async function closePopup(page) {
  for (const label of ['Dismiss', '关闭', 'Close']) {
    if (await exists(page, label, { role: 'button', timeout: 200 })) {
      await tapButton(page, label, { timeout: 1000 });
      await sleep(80);
      return;
    }
  }
  await page.keyboard.press('Escape').catch(() => {});
  await sleep(80);
}

const interactionExcludes = [
  '提交第', '朗读', '播放', '进入下一种挑战', '完成三连挑战', '再练重点项',
  '继续留下回忆', '完成挑战后继续', '返回', 'Back', '查看 Lv.', '提高当前难度',
  '降低当前难度', '短文复原', '语病修复', '补回句子', '简 / 繁', '声线', '减速',
  '加速', '提示', '继续', '上一步', '下一步', '返回首页', '分享旅程', '重新体验',
];

async function challengeOption(page) {
  const rs = await records(page);
  const lettered = rs
    .filter((r) => r.visible && !r.disabled && r.role === 'button' && /^[A-D]\s/.test(clean(r.label)) && /[\u3400-\u9fff]/.test(clean(r.label)))
    .sort((a, b) => a.index - b.index);
  if (lettered.length) return lettered[0];
  return rs
    .filter((r) => {
      if (!r.visible || r.disabled || !['button', 'checkbox', 'group'].includes(r.role)) return false;
      const text = recordText(r);
      if (text.length < 3 || !/[\u3400-\u9fff]/.test(text)) return false;
      return !interactionExcludes.some((item) => text.includes(item));
    })
    .sort((a, b) => b.area - a.area)[0] ?? null;
}

async function interactionTarget(page, stage) {
  if (stage === 1 || stage === 3) {
    return waitButtonEnabled(page, (text) => text === '注', 2500);
  }
  if (stage === 2) {
    return waitButtonEnabled(page, (text) =>
      /[\u3400-\u9fff]/.test(text) &&
      !interactionExcludes.some((item) => text.includes(item)) &&
      !/^\d+$/.test(text), 2500);
  }
  if (stage === 4) {
    const deadline = now() + 2500;
    while (now() < deadline) {
      const target = await challengeOption(page);
      if (target) return target;
      await sleep(25);
    }
    return null;
  }
  if (stage === 5 || stage === 6) {
    return waitButtonEnabled(page, (text) => /朗读|播放/.test(text), 2500);
  }
  return null;
}

async function verifyInteraction(page, stage, target) {
  if (!target) return { verified: false, mode: 'missing' };
  try {
    const locator = page.locator('flt-semantics').nth(target.index);
    const before = await visibleText(page);
    await locator.evaluate((el) => el.click());
    if (stage === 1) {
      await findSemantic(page, '故事第', { timeout: 2500 });
      await closePopup(page);
      return { verified: true, mode: 'story-annotation' };
    }
    if (stage === 2) {
      const opened = await exists(page, '收藏单词', { timeout: 1200 }) || await exists(page, '上一个单词', { timeout: 1200 });
      if (opened) await closePopup(page);
      return { verified: opened, mode: 'word-detail' };
    }
    if (stage === 3) {
      const opened = await exists(page, '今日发现', { timeout: 2000 }) && await exists(page, '拼音', { timeout: 2000 });
      if (opened) await closePopup(page);
      return { verified: opened, mode: 'discovery-support' };
    }
    if (stage === 4) {
      await sleep(80);
      const after = await visibleText(page);
      return { verified: after !== before, mode: 'challenge-option' };
    }
    if (stage === 5 || stage === 6) {
      await sleep(80);
      const stopTarget = await waitButtonEnabled(page, (text) => /暂停|停止/.test(text), 500);
      if (stopTarget) {
        await page.locator('flt-semantics').nth(stopTarget.index).evaluate((el) => el.click());
      } else {
        const same = await waitButtonEnabled(page, (text) => /朗读|播放/.test(text), 300);
        if (same) await page.locator('flt-semantics').nth(same.index).evaluate((el) => el.click());
      }
      await sleep(50);
      return { verified: true, mode: 'narration-button' };
    }
    return { verified: true, mode: 'button' };
  } catch (error) {
    return { verified: false, mode: 'error', error: String(error?.message || error) };
  }
}

async function setLevelQuiet(page, target) {
  for (let guard = 0; guard < 20; guard += 1) {
    const level = await currentLevel(page);
    if (level === target) {
      await sleep(350);
      return;
    }
    const direction = level < target ? '提高当前难度' : '降低当前难度';
    await tapButton(page, direction, { prefix: true, timeout: 6000 });
    const deadline = now() + 6000;
    while (now() < deadline) {
      const next = await currentLevel(page).catch(() => level);
      if (next !== level) break;
      await sleep(25);
    }
  }
  throw new Error(`failed to set quiet level ${target}`);
}

function median(values) {
  if (!values.length) return null;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

async function measureSwitch(page, stage, from, to, tag, requestLog) {
  const actual = await currentLevel(page);
  if (actual !== from) await setLevelQuiet(page, from);
  const beforeText = await canonicalStageText(page, stage);
  const beforeHash = hashText(beforeText);
  const requestStartIndex = requestLog.length;
  const t0 = now();
  const direction = to > from ? '提高当前难度' : '降低当前难度';
  await tapButton(page, direction, { prefix: true, timeout: 5000 });

  let t1 = null;
  const badgeDeadline = t0 + 3000;
  while (now() < badgeDeadline) {
    if ((await currentLevel(page).catch(() => from)) === to) {
      t1 = now();
      break;
    }
    await sleep(15);
  }

  const stable = await waitCanonicalStable(page, stage, { differentFrom: beforeHash, timeout: 5000, stableMs: 220 });
  const t2 = stable.firstChangedAt;
  const t3 = stable.timeout ? null : now();
  const target = await interactionTarget(page, stage);
  const t4 = target ? now() : null;
  const interaction = await verifyInteraction(page, stage, target);
  const afterText = await canonicalStageText(page, stage);
  const afterHash = hashText(afterText);
  const requests = requestLog.slice(requestStartIndex).map((entry) => entry.url);
  const result = {
    tag, stage, from, to,
    badgeMs: t1 == null ? null : Math.round(t1 - t0),
    contentMs: t2 == null ? null : Math.round(t2 - t0),
    semanticStableMs: t3 == null ? null : Math.round(t3 - t0),
    interactiveMs: t4 == null ? null : Math.round(t4 - t0),
    contentChanged: beforeHash !== afterHash,
    sourceHash: beforeHash,
    targetHash: afterHash,
    interactionVerified: interaction.verified,
    interactionMode: interaction.mode,
    requestCount: requests.length,
    requestUrls: [...new Set(requests)].slice(0, 12),
  };
  result.pass =
    result.badgeMs != null && result.badgeMs <= thresholds.badge &&
    result.contentMs != null && result.contentMs <= thresholds.content &&
    result.interactiveMs != null && result.interactiveMs <= thresholds.interactive &&
    result.contentChanged && result.interactionVerified;
  return result;
}

async function measureStage(page, stage, requestLog) {
  const results = [];
  await setLevelQuiet(page, 5);
  results.push(await measureSwitch(page, stage, 5, 6, '5>6-cold', requestLog));
  results.push(await measureSwitch(page, stage, 6, 5, '6>5-reverse', requestLog));
  results.push(await measureSwitch(page, stage, 5, 6, '5>6-warm2', requestLog));
  await setLevelQuiet(page, 5);
  results.push(await measureSwitch(page, stage, 5, 6, '5>6-warm3', requestLog));

  await setLevelQuiet(page, 8);
  results.push(await measureSwitch(page, stage, 8, 9, '8>9-cold', requestLog));
  results.push(await measureSwitch(page, stage, 9, 8, '9>8-reverse', requestLog));
  results.push(await measureSwitch(page, stage, 8, 9, '8>9-warm2', requestLog));
  await setLevelQuiet(page, 8);
  results.push(await measureSwitch(page, stage, 8, 9, '8>9-warm3', requestLog));
  await setLevelQuiet(page, 5);

  const primary = results.filter((r) => r.tag.includes('>6-') || r.tag.includes('>9-'));
  const badge = primary.map((r) => r.badgeMs).filter((v) => v != null);
  const content = primary.map((r) => r.contentMs).filter((v) => v != null);
  const interactive = primary.map((r) => r.interactiveMs).filter((v) => v != null);
  const cold = primary.filter((r) => r.tag.endsWith('cold'));
  const warm = primary.filter((r) => r.tag.includes('warm'));
  const agg = (field, set) => {
    const vals = set.map((r) => r[field]).filter((v) => v != null);
    return { median: median(vals), worst: vals.length ? Math.max(...vals) : null };
  };
  return {
    stage,
    pass: results.every((r) => r.pass),
    badge: { median: median(badge), worst: badge.length ? Math.max(...badge) : null, cold: agg('badgeMs', cold), warm: agg('badgeMs', warm) },
    content: { median: median(content), worst: content.length ? Math.max(...content) : null, cold: agg('contentMs', cold), warm: agg('contentMs', warm) },
    interactive: { median: median(interactive), worst: interactive.length ? Math.max(...interactive) : null, cold: agg('interactiveMs', cold), warm: agg('interactiveMs', warm) },
    results,
  };
}

async function chooseOptions(page) {
  const text = await visibleText(page);
  if (text.includes('第一步 · 点击有问题的部分')) {
    const segments = (await records(page)).filter((r) => r.visible && !r.disabled && r.role === 'checkbox' && /[\u3400-\u9fff]/.test(recordText(r)));
    if (segments.length) await page.locator('flt-semantics').nth(segments[0].index).evaluate((el) => el.click());
  }
  const countMatch = (await visibleText(page)).match(/依次点击\s*(\d+)\s*句/);
  const count = countMatch ? Number(countMatch[1]) : 1;
  const rs = await records(page);
  let targets = rs
    .filter((r) => r.visible && !r.disabled && r.role === 'button' && /^[A-D]\s/.test(clean(r.label)) && /[\u3400-\u9fff]/.test(clean(r.label)))
    .sort((a, b) => a.index - b.index);
  if (targets.length < count) {
    targets = rs
      .filter((r) => {
        if (!r.visible || r.disabled || !['button', 'checkbox', 'group'].includes(r.role)) return false;
        const txt = recordText(r);
        if (txt.length < 3 || !/[\u3400-\u9fff]/.test(txt)) return false;
        return !interactionExcludes.some((item) => txt.includes(item));
      })
      .sort((a, b) => b.area - a.area);
  }
  if (targets.length < count) throw new Error(`challenge options missing; need ${count}`);
  for (const target of targets.slice(0, count)) {
    await page.locator('flt-semantics').nth(target.index).evaluate((el) => el.click());
    await sleep(80);
  }
}

async function completeChallenge(page) {
  for (let mode = 0; mode < 3; mode += 1) {
    let advanced = false;
    for (let attempt = 1; attempt <= 3; attempt += 1) {
      await chooseOptions(page);
      await tapButton(page, '提交第', { prefix: true, timeout: 5000 });
      await sleep(250);
      if (await exists(page, '进入下一种挑战', { role: 'button', timeout: 500 })) {
        await tapButton(page, '进入下一种挑战');
        advanced = true;
        break;
      }
      if (await exists(page, '完成三连挑战', { role: 'button', timeout: 500 })) {
        await tapButton(page, '完成三连挑战');
        await findSemantic(page, '继续留下回忆', { timeout: 8000 });
        return;
      }
    }
    if (!advanced && !(await exists(page, '继续留下回忆', { timeout: 500 }))) {
      throw new Error(`challenge mode ${mode + 1} did not resolve`);
    }
  }
}

async function advance(page, stage) {
  if (stage === 1 || stage === 2 || stage === 3) {
    await tapButton(page, '继续', { prefix: true, timeout: 8000 });
    await waitStage(page, stage + 1, 15000);
    return;
  }
  if (stage === 4) {
    await completeChallenge(page);
    await tapButton(page, '继续留下回忆', { prefix: true, timeout: 8000 });
    await waitStage(page, 5, 15000);
    return;
  }
  if (stage === 5) {
    if (await exists(page, '保存回忆并完成', { role: 'button', prefix: true, timeout: 800 })) {
      await tapButton(page, '保存回忆并完成', { prefix: true, timeout: 8000 });
    } else {
      await tapButton(page, '结束旅程', { prefix: true, timeout: 8000 });
    }
    await waitStage(page, 6, 15000);
    return;
  }
}

async function extraRapid(page) {
  await setLevelQuiet(page, 5);
  const before = await currentLevel(page);
  const rs = await records(page);
  const plus = rs.find((r) => r.visible && r.role === 'button' && !r.disabled && recordText(r).startsWith('提高当前难度'));
  const minus = rs.find((r) => r.visible && r.role === 'button' && !r.disabled && recordText(r).startsWith('降低当前难度'));
  if (!plus || !minus) return { pass: false, reason: 'level buttons missing' };
  await page.locator('flt-semantics').nth(plus.index).evaluate((el) => el.click());
  await sleep(20);
  const rs2 = await records(page);
  const minus2 = rs2.find((r) => r.visible && r.role === 'button' && !r.disabled && recordText(r).startsWith('降低当前难度'));
  let secondAccepted = false;
  if (minus2) {
    await page.locator('flt-semantics').nth(minus2.index).evaluate((el) => el.click());
    secondAccepted = true;
  }
  await sleep(1200);
  const finalLevel = await currentLevel(page).catch(() => null);
  return { before, secondAccepted, finalLevel, pass: secondAccepted && finalLevel === before };
}

async function run() {
  const browser = browserName === 'webkit'
    ? await webkit.launch({ headless: true })
    : await chromium.launch({ headless: true });
  const contextOptions = browserName === 'webkit'
    ? { ...devices['iPhone 13'], locale: 'zh-CN', reducedMotion: 'reduce' }
    : { viewport: { width: 1280, height: 900 }, locale: 'zh-CN', reducedMotion: 'reduce' };
  const context = await browser.newContext(contextOptions);
  const page = await context.newPage();
  const pageErrors = [];
  const failedRequests = [];
  const requestLog = [];
  page.on('pageerror', (error) => pageErrors.push(error?.stack || error?.message || String(error)));
  page.on('requestfailed', (request) => failedRequests.push(`${request.url()} :: ${request.failure()?.errorText || 'failed'}`));
  page.on('request', (request) => requestLog.push({ at: now(), url: request.url(), resourceType: request.resourceType() }));

  const result = {
    sha: sourceSha,
    cityKey,
    city: journey.city,
    place: journey.place,
    browser: browserName,
    thresholds,
    stages: {},
    extras: {},
    pageErrors,
    failedRequests,
  };

  try {
    await startup(page);
    await openJourney(page);
    await setLevelQuiet(page, 5);
    for (let stage = 1; stage <= 6; stage += 1) {
      if ((await currentStage(page).catch(() => null)) !== stage) throw new Error(`unexpected stage before probe: ${stage}`);
      result.stages[stage] = await measureStage(page, stage, requestLog);
      console.log(`PERF_STAGE ${cityKey} ${browserName} stage=${stage} pass=${result.stages[stage].pass} contentMedian=${result.stages[stage].content.median} contentWorst=${result.stages[stage].content.worst}`);
      if (stage < 6) await advance(page, stage);
    }
    if (cityKey === 'xian') {
      await tapButton(page, '重新体验', { prefix: true, timeout: 8000 });
      await waitStage(page, 1, 15000);
      result.extras.rapidPlusMinus = await extraRapid(page);
    }
    result.networkDuringSwitches = requestLog.filter((r) => !/^(data:|blob:)/.test(r.url)).map((r) => r.url);
    result.pass = Object.values(result.stages).every((s) => s.pass) && (!result.extras.rapidPlusMinus || result.extras.rapidPlusMinus.pass);
  } catch (error) {
    result.error = String(error?.stack || error);
    result.pass = false;
  } finally {
    result.pageErrors = pageErrors;
    result.failedRequests = failedRequests;
    console.log(`PERF_RESULT_JSON=${JSON.stringify(result)}`);
    await context.close();
    await browser.close();
  }
}

await run();
